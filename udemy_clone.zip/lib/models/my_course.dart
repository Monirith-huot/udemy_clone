class MyCourse {
  final String title;
  final String instructorName;
  final int progree;
  final String image;

  const MyCourse({
    required this.title,
    required this.instructorName,
    required this.progree,
    required this.image,
  });
}
